'use strict';
/* CampusFix: frontend prototype. All data lives in localStorage (no backend). */

const KEY = 'campusfix_complaints';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const RANK = { Normal: 1, High: 2, Critical: 3 };
const ICON = { 'Pending': '🟡', 'In Progress': '🔵', 'Resolved': '🟢' };
const STEPS = ['Submitted', 'Pending', 'In Progress', 'Resolved'];

let complaints = load();
let filter = 'All';

/* ---------- Storage helpers ---------- */
function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; }
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(complaints)); }
  catch (e) { toast('Storage is full. Try a smaller photo.'); }
}
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const cls = s => s.replace(' ', '').toLowerCase();

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.remove('show'), 2600);
}

/* ---------- Duplicate detection ---------- */
// Words that say nothing about WHAT is broken, so they are ignored when comparing.
const STOP = new Set(('a an the is are was in at on of to for not no and or it its my our with has have had be been very too ' +
  'working work problem problems issue issues broken damaged fix please class classroom room running runs run stopped bad').split(' '));

// Turns title + description into a set of simple, stemmed keywords.
function keywords(c) {
  return new Set(
    `${c.title} ${c.desc || ''}`.toLowerCase().replace(/wi-?fi/g, 'wifi').replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2 && !STOP.has(w) && !/^[a-z]?\d+$/.test(w)) // drop room codes like j304
      .map(w => w.replace(/(ing|es|s)$/, ''))
  );
}
const normLoc = l => l.toLowerCase().replace(/[^a-z0-9]/g, '');

// Two complaints are "similar" when location AND category match and they share at least one keyword.
function isSimilar(a, b) {
  if (normLoc(a.location) !== normLoc(b.location) || a.category !== b.category) return false;
  const kb = keywords(b);
  return [...keywords(a)].some(w => kb.has(w));
}
// Looks for an unresolved complaint similar to the given one.
const findSimilar = c => complaints.find(x => x.status !== 'Resolved' && isSimilar(c, x));

/* ---------- Complaint creation ---------- */
function newId() {
  let id;
  do { id = 'CF-' + (10000 + Math.floor(Math.random() * 90000)); } while (complaints.some(c => c.id === id));
  return id;
}

// Saves a complaint; if a similar one exists it joins that complaint's group (groupId).
function addComplaint(d) {
  const c = { ...d, id: newId(), status: d.status || 'Pending', date: d.date || new Date().toISOString() };
  const match = findSimilar(c);
  c.groupId = match ? match.groupId : c.id;
  complaints.unshift(c);
  save();
  return { c, match };
}

/* ---------- Groups ---------- */
const groups = () => {
  const map = {};
  complaints.forEach(c => (map[c.groupId] = map[c.groupId] || []).push(c));
  return Object.values(map).filter(g => g.length > 1);
};
const topPriority = g => g.reduce((p, c) => (RANK[c.priority] > RANK[p] ? c.priority : p), 'Normal');

// Builds a label such as "A-304 — Fan Problem" from the most common keyword in the group.
function groupLabel(g) {
  const count = {};
  g.forEach(c => keywords(c).forEach(w => (count[w] = (count[w] || 0) + 1)));
  const best = Object.keys(count).sort((a, b) => count[b] - count[a])[0] || g[0].category;
  return `${g[0].location} — ${best.charAt(0).toUpperCase() + best.slice(1)} Problem`;
}

function groupCard(g, admin) {
  const key = g[0].groupId;
  const actions = admin ? `<div class="group-actions">${['Pending', 'In Progress', 'Resolved'].map(s =>
    `<button data-gact="${s}" data-group="${esc(key)}">All ${s}</button>`).join('')}</div>` : '';
  return `<article class="group-card">
    <div class="group-tag">🔗 SAME ISSUE</div>
    <h3>${esc(groupLabel(g))}</h3>
    <p class="muted">${g.length} complaints</p>
    <div class="chips">${g.map(c => `<span>${c.id}</span>`).join('')}</div>
    <span class="prio ${topPriority(g)}">Priority: ${topPriority(g)}</span>${actions}
  </article>`;
}

/* ---------- Rendering ---------- */
const badge = s => `<span class="status ${cls(s)}">${ICON[s]} ${s}</span>`;

function card(c) {
  return `<article class="card complaint ${c.priority === 'Critical' ? 'critical' : ''}">
    <div class="row"><span class="cid">${c.id}</span>${badge(c.status)}</div>
    <h3>${esc(c.title)}</h3>
    <p class="meta">${esc(c.category)} · ${esc(c.location)} · ${fmt(c.date)}</p>
    <div class="row"><span class="prio ${c.priority}">${c.priority}</span><button class="link" data-track="${c.id}">Track</button></div>
  </article>`;
}

function stats(list, withCritical) {
  const n = s => list.filter(c => c.status === s).length;
  const items = [['Total ' + (withCritical ? 'Issues' : 'Complaints'), list.length, ''], ['Pending', n('Pending'), 'pending'],
    ['In Progress', n('In Progress'), 'progress'], ['Resolved', n('Resolved'), 'resolved']];
  if (withCritical) items.push(['Critical Issues', list.filter(c => c.priority === 'Critical' && c.status !== 'Resolved').length, 'critical']);
  return items.map(([l, v, k]) => `<div class="card stat ${k}"><b>${v}</b><span>${l}</span></div>`).join('');
}

const emptyMsg = t => `<p class="empty">${t}</p>`;

function renderDashboard() {
  $('#studentStats').innerHTML = stats(complaints, false);
  const g = groups();
  $('#studentGroups').innerHTML = g.length ? g.map(x => groupCard(x, false)).join('') : emptyMsg('No repeated complaints yet.');
  $('#recentList').innerHTML = complaints.length ? complaints.slice(0, 3).map(card).join('')
    : emptyMsg('No complaints yet. Raise one, or use Load Demo Data.');
}

function renderMine() {
  const q = $('#searchBox').value.trim().toLowerCase();
  const list = complaints.filter(c => (filter === 'All' || c.status === filter) &&
    `${c.id} ${c.title} ${c.location} ${c.category}`.toLowerCase().includes(q));
  $('#mineList').innerHTML = list.length ? list.map(card).join('') : emptyMsg('No complaints match your search.');
}

function renderAdmin() {
  $('#adminStats').innerHTML = stats(complaints, true);
  const g = groups();
  $('#adminGroups').innerHTML = g.length ? g.map(x => groupCard(x, true)).join('') : emptyMsg('No grouped issues yet.');
  // Critical first, then newest
  const sorted = [...complaints].sort((a, b) => RANK[b.priority] - RANK[a.priority] || new Date(b.date) - new Date(a.date));
  $('#adminRows').innerHTML = sorted.length ? sorted.map(c => `<tr class="${c.priority === 'Critical' ? 'critical' : ''}">
    <td><b>${c.id}</b></td><td>${esc(c.title)}</td><td>${esc(c.category)}</td><td>${esc(c.location)}</td>
    <td>${esc(c.name)}<br><small class="muted">${esc(c.sid)}</small></td>
    <td><span class="prio ${c.priority}">${c.priority}</span></td><td>${badge(c.status)}</td><td>${fmt(c.date)}</td>
    <td><div class="acts">
      <button data-act="Pending" data-id="${c.id}" title="Set Pending">Set Pending</button>
      <button data-act="In Progress" data-id="${c.id}" title="Set In Progress">Set In Progress</button>
      <button data-act="Resolved" data-id="${c.id}" title="Set Resolved">Set Resolved</button>
      <button class="del" data-act="delete" data-id="${c.id}">Delete</button></div></td></tr>`).join('')
    : `<tr><td colspan="9">${emptyMsg('No complaints yet.')}</td></tr>`;
}

// Shows the tracker for one complaint ID.
function renderTrack(id) {
  const c = complaints.find(x => x.id === id.trim().toUpperCase());
  const box = $('#trackResult');
  if (!c) { box.innerHTML = emptyMsg('No complaint found with that ID. Check it and try again.'); return; }
  const current = 1 + ['Pending', 'In Progress', 'Resolved'].indexOf(c.status);
  const mates = complaints.filter(x => x.groupId === c.groupId && x.id !== c.id);
  box.innerHTML = `<article class="card">
    <div class="row"><h3>${c.id}: ${esc(c.title)}</h3>${badge(c.status)}</div>
    <div class="detail-grid">
      <div><span>Category</span>${esc(c.category)}</div><div><span>Location</span>${esc(c.location)}</div>
      <div><span>Priority</span><b class="prio ${c.priority}">${c.priority}</b></div><div><span>Submitted</span>${fmt(c.date)}</div>
      <div><span>Student</span>${esc(c.name)} (${esc(c.sid)})</div></div>
    ${c.desc ? `<p>${esc(c.desc)}</p>` : ''}${c.photo ? `<img src="${c.photo}" alt="Complaint photo" style="max-width:260px;border-radius:12px">` : ''}
    <ol class="tracker">${STEPS.map((s, i) => `<li class="${i <= current ? 'done' : ''} ${i === current ? 'current' : ''}">${s}</li>`).join('')}</ol>
    ${mates.length ? `<div class="hint">🔗 Same issue as ${mates.map(m => m.id).join(', ')}. One fix resolves all of them.</div>` : ''}
  </article>`;
}

/* ---------- Navigation ---------- */
function show(view) {
  $$('.view').forEach(v => v.classList.toggle('active', v.id === view));
  $$('#studentLinks button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  $('#studentLinks').hidden = view === 'admin';
  $$('.role-toggle button').forEach(b => b.classList.toggle('active', (b.dataset.role === 'admin') === (view === 'admin')));
  if (view === 'dashboard') renderDashboard();
  if (view === 'mine') renderMine();
  if (view === 'admin') renderAdmin();
  $('#nav').classList.remove('open');
  $('#menuBtn').setAttribute('aria-expanded', 'false');
  window.scrollTo(0, 0);
}

/* ---------- Events ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('button');
  if (!t) return;
  if (t.dataset.view) show(t.dataset.view);
  if (t.dataset.role) show(t.dataset.role === 'admin' ? 'admin' : 'dashboard');
  if (t.dataset.track) { $('#trackInput').value = t.dataset.track; show('track'); renderTrack(t.dataset.track); }
  if (t.classList.contains('demo-btn')) loadDemo();
  if (t.dataset.act) adminAction(t.dataset.id, t.dataset.act);
  if (t.dataset.gact) { // change the status of every complaint in a group
    complaints.forEach(c => { if (c.groupId === t.dataset.group) c.status = t.dataset.gact; });
    save(); renderAdmin(); toast('Group updated.');
  }
});

// Admin: change status or delete; saves to localStorage so the student side updates instantly.
function adminAction(id, act) {
  if (act === 'delete') {
    if (!confirm('Delete complaint ' + id + '?')) return;
    complaints = complaints.filter(c => c.id !== id);
  } else {
    const c = complaints.find(x => x.id === id);
    if (c) c.status = act;
  }
  save(); renderAdmin(); toast('Updated.');
}

$('#menuBtn').addEventListener('click', () => {
  const open = $('#nav').classList.toggle('open');
  $('#menuBtn').setAttribute('aria-expanded', open);
});

$('#searchBox').addEventListener('input', renderMine);
$('#filters').addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b) return;
  filter = b.dataset.f;
  $$('#filters button').forEach(x => x.classList.toggle('active', x === b));
  renderMine();
});

$('#trackForm').addEventListener('submit', e => { e.preventDefault(); renderTrack($('#trackInput').value); });
$('#clearBtn').addEventListener('click', () => {
  if (complaints.length && confirm('Delete all complaints?')) { complaints = []; save(); renderAdmin(); toast('All data cleared.'); }
});

// Live warning while the student is typing a complaint.
const form = $('#complaintForm');
form.addEventListener('input', () => {
  const d = Object.fromEntries(new FormData(form));
  const hint = $('#similarHint');
  const m = d.title && d.location ? findSimilar({ ...d, desc: d.desc || '' }) : null;
  hint.hidden = !m;
  if (m) hint.textContent = `Similar complaint detected: ${m.id} "${m.title}". Yours will be grouped with it.`;
});

// Reads an optional photo as a data URL (small files only, to protect localStorage).
function readPhoto(file) {
  return new Promise(res => {
    if (!file || !file.size) return res('');
    if (file.size > 400000) { toast('Photo is over 400 KB, so it was skipped.'); return res(''); }
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => res('');
    r.readAsDataURL(file);
  });
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(form));
  d.photo = await readPhoto(form.photo.files[0]);
  const { c, match } = addComplaint(d);
  $('#raiseResult').innerHTML = `<article class="card success">
    <h3>✅ Complaint submitted successfully.</h3>
    <p class="muted">Your Complaint ID</p><p class="big">${c.id}</p>
    <p>Status: ${badge(c.status)}</p>
    ${match ? `<div class="hint">⚠️ Similar complaint detected. This complaint has been grouped with ${match.id}.</div>
      <div class="groups" style="margin-top:1rem">${groupCard(complaints.filter(x => x.groupId === c.groupId), false)}</div>` : ''}
    <div class="btn-row" style="margin-top:1rem"><button class="btn primary" data-track="${c.id}">Track this complaint</button>
    <button class="btn ghost" data-view="dashboard">Go to dashboard</button></div></article>`;
  form.reset();
  $('#similarHint').hidden = true;
  toast('Complaint submitted successfully.');
  window.scrollTo(0, 0);
});

/* ---------- Demo data ---------- */
function loadDemo() {
  if (complaints.length && !confirm('Replace existing complaints with demo data?')) return;
  complaints = [];
  const day = n => new Date(Date.now() - n * 864e5).toISOString();
  [
    { name: 'Aarav Sharma', sid: '21260145', title: 'Fan not working in A-304', category: 'Electricity', location: 'A-304', priority: 'High', status: 'Pending', date: day(4), desc: 'Ceiling fan has stopped completely.' },
    { name: 'Meera Nair', sid: '21260211', title: 'A-304 fan problem', category: 'Electricity', location: 'A-304', priority: 'Normal', status: 'Pending', date: day(3), desc: '' },
    { name: 'Rohan Das', sid: '21260390', title: 'Water cooler not working', category: 'Water', location: 'A-201', priority: 'High', status: 'In Progress', date: day(2), desc: 'No cold water on the ground floor.' },
    { name: 'Sara Khan', sid: '21260120', title: 'Wi-Fi slow in library', category: 'Internet / Wi-Fi', location: 'Library', priority: 'Normal', status: 'Resolved', date: day(1), desc: '' }
  ].forEach(addComplaint); // addComplaint groups the two A-304 fan complaints automatically
  toast('Demo data loaded.');
  show($('#admin').classList.contains('active') ? 'admin' : 'dashboard');
}
